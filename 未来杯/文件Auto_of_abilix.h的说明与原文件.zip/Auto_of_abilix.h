#ifndef _Auto_of_abilix
#define _Auto_of_abilix

//引用头文件（必须文件 Robot.h）
#include "Robot.h"

//此处为了方便编写代码减少输入‘号 故意定义了宏

//定义了转弯类型
#define tl 'l'
#define tr 'r'
#define ts 's'
#define ta 'a'
#define tb 'b'

//定义了路口类型
#define rl 'l'
#define rr 'r'
#define rt 't'
//宏变量定义完成

//最大速度 大角度转弯所用 最小速度 精确定位用 中间速度 前进后退以及小角度转弯
//常数的定义 方便调用和调错
/* 
int speed_max = 100;
int speed_min = 50;
int speed_between = 75;
char turning_mode = 's';
float timer = 0.1; 

默认变量定义 
				电机速度int
				最大 	    100 
				最小 		50 	
				中间速度 	75
				
				转弯类型char	默认小角度
				小角度转弯 	‘s’
				大角度转弯  ‘b’ 	
				
				timer根据转弯类型判断 
				转弯通过路口时间 默认 0.1
				但当其为大角度转弯时 自动设为 0
*/
int speed_max = 100;
int speed_min = 50;
int speed_between = 75;
char turning_mode = 's';
float timer = 0.1;

//初始化变量定义需要运行
void Auto_Init(int speedA,int speedB.int speedC,char turning_mode1){
	speed_max = speedA;
	speed_between = speedB;
	speed_min = speedC;
	turning_mode = turning_mode1;
	if (turning_mode == 'b'){
		timer = 0;
	}
	else{
		timer = 0.1;
	}
}

//定义了转向函数 自动转向 根据前面所给转向类型 进行执行左转右转 前进后退
void Turn(char op){
	switch(op){
		case 'l':
			if (turning_mode == 'b'){
			WER_Around(0,speed_max,2);
			}else if(turning_mode == 's'){
			WER_Around(-speed_between,speed_between,2);
			}
		break;
		case 'r':
			if (turning_mode == 'b'){
			WER_Around(speed_max,0,2);
			}else if(turning_mode == 's'){
			WER_Around(speed_between,-speed_between,2);
			}
		break;
		case 'a':
			WER_Around(speed_between,speed_between,2);
		break;
		case 'b':
			WER_Around(-speed_between,-speed_between,2);
		break;
		case 's': 
			Stop();
		break;
		default:break;
	}
}

//停止电机
void Stop(){
	WER_SetMotor_T(0,0,0.1);
}

//定义了一个通用执行器函数 
//常用执行器函数需要输入两个变量 
//一个是路口类型一个是遇到这个路口后的操作指令

//第一个变量 字符型变量 char   t T字路口    x 十字路口   r 左右转弯路口
//第二个变量 字符型变量 char   l 左转       r 右转       a 直行           s 停下 
void Auto_Common_Executer(char road_type,char operations){
	WER_SetMotor_T(speed_between,speed_between,0.2);
	switch(road_type){
		case 't':	
			WER_LineWay_C(speed_between,15, timer);
			switch(operations){
				case 'l':Turn('l');break;
				case 'r':Turn('r');break;
				case 'a':Turn('a');break;
				case 's':Stop();break;
				case 'b':Turn('b');break;
				default:break;
			}
			break;
		case 'l':	
			WER_LineWay_C(speed_between,1, timer);
			switch(operations){
				case 'l':Turn('l');break;
				case 'a':Turn('a');break;
				case 's':Stop();break;
				case 'b':Turn('b');break;
				default:break;
			}
			break;	
		case 'r':
			WER_LineWay_C(speed_between,5,timer);
			switch(operations){
				case 'r':Turn('r');break;
				case 'a':Turn('a');break;
				case 's':Stop();break;
				case 'b':Turn('b');break;
				default:break;
			}
			break;
		default:
			break;
	}
}

#endif